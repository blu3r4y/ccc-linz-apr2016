/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones.streams;

import cc.catalysts.contest.drones.streams.StreamProvider;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

public class StandardStreamProvider
implements StreamProvider {
    @Override
    public InputStream getInputStream() {
        return System.in;
    }

    @Override
    public OutputStream getOutputStream() {
        return System.out;
    }

    @Override
    public boolean reset() throws IOException {
        return false;
    }

    @Override
    public void close() throws Exception {
        System.in.close();
        System.out.close();
    }
}

