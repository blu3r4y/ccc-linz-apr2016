/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones.streams;

import cc.catalysts.contest.drones.streams.StreamProvider;
import com.google.common.base.Optional;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkStreamProvider
implements StreamProvider {
    private final ServerSocket serverSocket;
    private Optional<Socket> socket;

    public NetworkStreamProvider(int port, int timeout) throws IOException {
        this.serverSocket = new ServerSocket(port);
        this.serverSocket.setSoTimeout(timeout);
        this.socket = Optional.absent();
        System.out.println("Ready to accept connections at " + this.serverSocket.getInetAddress().getHostAddress() + ":" + this.serverSocket.getLocalPort());
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if (!this.socket.isPresent()) {
            this.socket = Optional.of(this.serverSocket.accept());
        }
        return this.socket.get().getInputStream();
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        if (!this.socket.isPresent()) {
            this.socket = Optional.of(this.serverSocket.accept());
        }
        return this.socket.get().getOutputStream();
    }

    @Override
    public boolean reset() throws IOException {
        if (!this.socket.isPresent()) {
            throw new IllegalStateException("There are no underlying streams to be reset.");
        }
        this.socket.get().close();
        this.socket = Optional.absent();
        System.out.println("Connection closed, reconnect to start over.");
        return true;
    }

    @Override
    public void close() throws Exception {
        if (!this.socket.isPresent()) {
            throw new IllegalStateException("There are no underlying streams to be reset.");
        }
        this.socket.get().close();
        this.socket = Optional.absent();
        this.serverSocket.close();
        System.out.println("Bye!");
    }
}

