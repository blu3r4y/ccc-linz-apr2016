/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones;

import cc.catalysts.contest.drones.AbstractPlayer;
import cc.catalysts.contest.drones.PlayerFactory;
import cc.catalysts.contest.drones.streams.NetworkStreamProvider;
import cc.catalysts.contest.drones.streams.StandardStreamProvider;
import com.google.common.base.Optional;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;
import org.apache.commons.io.input.TeeInputStream;
import org.apache.commons.io.output.NullOutputStream;

public class Simulator {
    private final PlayerFactory factory;
    private static boolean onCoduno = Boolean.parseBoolean(System.getenv("CODUNO"));
    private static final String USAGE = "Usage: java -jar simulator.jar <level> <testcase> [port]\n\nWhere\n\tlevel is in [1 - 7]\n\ttestcase is in [1 - 3]\n\tport is optional and in [1-65535]\n\n";

    public Simulator(PlayerFactory factory) {
        this.factory = factory;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run(String[] args) throws Exception {
        boolean verify;
        File dir;
        if (args.length < 2) {
            System.err.println("Usage: java -jar simulator.jar <level> <testcase> [port]\n\nWhere\n\tlevel is in [1 - 7]\n\ttestcase is in [1 - 3]\n\tport is optional and in [1-65535]\n\n");
            return;
        }
        int l = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        Optional p = args.length >= 3 ? Optional.of(Integer.parseInt(args[2])) : Optional.absent();
        boolean bl = verify = p.isPresent() && (Integer)p.get() < 1;
        if (!verify && !(dir = new File(".")).canWrite()) {
            System.err.println("Cannot write to " + dir.getAbsolutePath());
            System.err.println("Please run this program in a directory with write access!");
            System.exit(1);
        }
        StandardStreamProvider sp = p.isPresent() && (Integer)p.get() != 0 ? new NetworkStreamProvider(Math.abs((Integer)p.get()), verify ? 10000 : 0) : new StandardStreamProvider();
        Throwable throwable = null;
        try {
            do {
                ByteArrayOutputStream log = verify ? null : new ByteArrayOutputStream();
                InputStream in = verify ? sp.getInputStream() : new TeeInputStream(sp.getInputStream(), log);
                OutputStream out = verify ? new NullOutputStream() : sp.getOutputStream();
                Scanner sc = new Scanner(in);
                sc.useLocale(Locale.US);
                boolean success = this.factory.getPlayer(l, t, out, sc).handle();
                if (onCoduno) {
                    System.exit(success ? 0 : 1);
                    return;
                }
                if (!success || verify) continue;
                File f = new File("solution-" + l + "-" + t + ".txt");
                PrintWriter dump = new PrintWriter(f, "UTF-8");
                dump.print(log.toString().replaceAll("(STATUS|SCAN) \\d+\n", ""));
                dump.close();
                System.out.println("Level complete! Please upload the file\n\n\t" + f.getAbsolutePath() + "\n\nto the contest system!");
                System.exit(0);
            } while (sp.reset());
        }
        catch (Throwable log) {
            throwable = log;
            throw log;
        }
        finally {
            if (sp != null) {
                if (throwable != null) {
                    try {
                        sp.close();
                    }
                    catch (Throwable var13_16) {
                        throwable.addSuppressed(var13_16);
                    }
                } else {
                    sp.close();
                }
            }
        }
        System.exit(1);
    }
}

