/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import com.google.common.base.Optional;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class AbstractPlayer<T extends Simulation> {
    protected final Level<T> level;
    protected final PrintWriter out;
    protected final Scanner sc;

    protected AbstractPlayer(Level<T> level, OutputStream out, Scanner sc) {
        this.level = level;
        this.out = new PrintWriter(out, true);
        this.sc = sc;
    }

    protected void ok() {
        this.out.println("OK");
    }

    protected abstract Optional<Boolean> dispatchCommand(String var1) throws IOException;

    public boolean handle() throws IOException {
        this.level.init(this.out);
        while (this.sc.hasNext()) {
            try {
                Optional<Boolean> done = this.dispatchCommand(this.sc.next().toLowerCase());
                if (!done.isPresent()) continue;
                return done.get();
            }
            catch (IllegalArgumentException dnfe) {
                this.out.println("FAIL There is no drone with the ID you requested.");
                dnfe.printStackTrace();
                return false;
            }
            catch (InputMismatchException imme) {
                this.out.println("FAIL A message you sent does not conform with the specification.");
                imme.printStackTrace();
                return false;
            }
            catch (Exception e) {
                this.out.println("FAIL " + e.getClass().getName() + ": " + e.getMessage());
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }
}

