/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones.level;

import cc.catalysts.contest.drones.Simulation;
import java.io.PrintWriter;

public abstract class Level<T extends Simulation> {
    protected final T simulation;

    public Level(T simulation) {
        this.simulation = simulation;
    }

    public abstract boolean success();

    public abstract void init(PrintWriter var1);

    public T getSimulation() {
        return this.simulation;
    }
}

