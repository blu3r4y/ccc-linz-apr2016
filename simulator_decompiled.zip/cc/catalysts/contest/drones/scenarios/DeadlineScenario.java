/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones.scenarios;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones.scenarios.Scenario;

public abstract class DeadlineScenario<T extends Simulation, U extends Number>
implements Scenario<T> {
    protected final U deadline;

    public DeadlineScenario(U deadline) {
        this.deadline = deadline;
    }

    @Override
    public abstract Level<T> initialize();
}

