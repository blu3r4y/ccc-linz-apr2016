/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones.scenarios;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;

public interface Scenario<T extends Simulation> {
    public Level<T> initialize();
}

