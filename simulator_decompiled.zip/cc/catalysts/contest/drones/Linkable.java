/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones;

import com.google.common.base.Optional;

public abstract class Linkable<T> {
    private Optional<T> link = Optional.absent();

    protected Linkable() {
    }

    public T getLink() {
        if (!this.link.isPresent()) {
            throw new IllegalStateException("Linkable is not linked!");
        }
        return this.link.get();
    }

    public boolean isLinked() {
        return this.link.isPresent();
    }

    public void link(T link) {
        if (this.link.isPresent()) {
            throw new IllegalStateException("Linkable already associated to a link!");
        }
        this.link = Optional.fromNullable(link);
    }

    public void unlink() {
        this.link = Optional.absent();
    }
}

