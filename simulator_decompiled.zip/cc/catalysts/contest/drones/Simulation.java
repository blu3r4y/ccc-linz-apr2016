/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones;

public interface Simulation {
}

