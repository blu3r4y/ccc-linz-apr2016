/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones;

import cc.catalysts.contest.drones.AbstractPlayer;
import cc.catalysts.contest.drones.Simulation;
import java.io.OutputStream;
import java.util.Scanner;

public interface PlayerFactory<T extends Simulation> {
    public AbstractPlayer<T> getPlayer(int var1, int var2, OutputStream var3, Scanner var4);
}

