/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones.scenarios.Scenario;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.HoverLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.util.ArrayList;
import java.util.List;

public class Scenario23
implements Scenario<Simulation3D> {
    private static final double PADDING = 10.0;
    private static final int DRONE_COUNT = 20;

    @Override
    public Level<Simulation3D> initialize() {
        ArrayList<Drone> drones = new ArrayList<Drone>(20);
        for (int i = 0; i < 20; ++i) {
            drones.add(new Drone(Vector2D.dia(10.0 + (double)i * 10.0).toVector3D()));
        }
        Simulation3D simulation3D = new Simulation3D(Terrain.flat(Vector2D.dia(220.0)), drones);
        if (simulation3D.isValid()) {
            return new HoverLevel(simulation3D);
        }
        throw new InternalError("Level creation failed");
    }
}

