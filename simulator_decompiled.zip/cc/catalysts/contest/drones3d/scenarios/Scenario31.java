/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.TargetLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.Collections;
import java.util.List;

public class Scenario31
extends DoubleDeadlineScenario {
    public Scenario31() {
    }

    public Scenario31(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Vector2D terrainSize = Vector2D.dia(20.0);
        Terrain terrain = Terrain.flat(terrainSize);
        List<Drone> drones = Collections.singletonList(new Drone(new Vector3D(5.0, 10.0, 0.0)));
        List<Vector3D> targets = Collections.singletonList(new Vector3D(15.0, 10.0, 0.0));
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline);
        if (simulation3D.isValid()) {
            return new TargetLevel(simulation3D, targets);
        }
        throw new InternalError("Level creation failed");
    }
}

