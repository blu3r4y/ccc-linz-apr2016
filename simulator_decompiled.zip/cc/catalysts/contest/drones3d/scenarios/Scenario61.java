/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.DeliveryLevel;
import cc.catalysts.contest.drones3d.map.ChargingStation;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Scenario61
extends DoubleDeadlineScenario {
    public Scenario61(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Random rnd = new Random(1);
        Vector2D terrainSize = new Vector2D(80.0, 80.0);
        Terrain terrain = Terrain.flat(terrainSize);
        double maxPackageMass = 2.0;
        double maxChargingRate = 800.0;
        ArrayList<Drone> drones = new ArrayList<Drone>();
        for (int i = 0; i < 2; ++i) {
            Vector2D pos = new Vector2D(rnd.nextDouble() * terrainSize.x, rnd.nextDouble() * terrainSize.y);
            drones.add(new Drone(terrain.translate(pos), 3.0));
        }
        ArrayList<Parcel> parcels = new ArrayList<Parcel>();
        for (int i2 = 0; i2 < 10; ++i2) {
            Vector2D pos = new Vector2D(rnd.nextDouble() * terrainSize.x, rnd.nextDouble() * terrainSize.y);
            Vector2D target = new Vector2D(rnd.nextDouble() * terrainSize.x, rnd.nextDouble() * terrainSize.y);
            parcels.add(new Parcel(rnd.nextDouble() * maxPackageMass, terrain.translate(pos), terrain.translate(target)));
        }
        ArrayList<ChargingStation> chargingStations = new ArrayList<ChargingStation>();
        for (int i3 = 0; i3 < 5; ++i3) {
            Vector2D pos = new Vector2D(rnd.nextDouble() * terrainSize.x, rnd.nextDouble() * terrainSize.y);
            chargingStations.add(new ChargingStation(terrain.translate(pos), (int)(rnd.nextDouble() * maxChargingRate)));
        }
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline, chargingStations, parcels);
        if (simulation3D.isValid()) {
            return new DeliveryLevel(simulation3D);
        }
        throw new InternalError("Level creation failed");
    }
}

