/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.scenarios.DeadlineScenario;
import cc.catalysts.contest.drones3d.Simulation3D;

public abstract class DoubleDeadlineScenario
extends DeadlineScenario<Simulation3D, Double> {
    public DoubleDeadlineScenario() {
        super(Double.POSITIVE_INFINITY);
    }

    public DoubleDeadlineScenario(double deadline) {
        super(deadline);
    }
}

