/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.TargetLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import cc.catalysts.contest.drones3d.scenarios.ScenarioUtil;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public class Scenario33old
extends DoubleDeadlineScenario {
    private static double SIZE = 1000.0;
    private static int DRONE_COUNT = 100;

    public Scenario33old() {
    }

    public Scenario33old(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Random rnd = new Random(1);
        Terrain terrain = Terrain.flat(new Vector2D(SIZE + 10.0, SIZE + 10.0));
        List<Drone> drones = ScenarioUtil.randomAndSafeDrones(rnd, new Vector2D(5.0, 5.0), new Vector2D(SIZE / 2.0, SIZE / 2.0), 5.0, terrain, DRONE_COUNT / 2);
        drones.addAll(ScenarioUtil.randomAndSafeDrones(rnd, new Vector2D(5.0, SIZE / 2.0), new Vector2D(SIZE / 2.0, SIZE / 2.0 - 5.0), 5.0, terrain, DRONE_COUNT / 2));
        List<Vector3D> targets = ScenarioUtil.randomAndSafe(rnd, new Vector2D(SIZE / 2.0, SIZE / 2.0), new Vector2D(SIZE / 2.0 - 5.0, SIZE / 2.0 - 5.0), 5.0, terrain, DRONE_COUNT / 2);
        targets.addAll(ScenarioUtil.randomAndSafe(rnd, new Vector2D(SIZE / 2.0, 5.0), new Vector2D(SIZE / 2.0 - 5.0, SIZE / 2.0 - 5.0), 5.0, terrain, DRONE_COUNT / 2));
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline);
        if (simulation3D.isValid()) {
            return new TargetLevel(simulation3D, targets);
        }
        throw new InternalError("Level creation failed");
    }
}

