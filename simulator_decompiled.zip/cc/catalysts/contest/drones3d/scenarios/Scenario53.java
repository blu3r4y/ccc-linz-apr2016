/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.DeliveryLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.Arrays;
import java.util.List;

public class Scenario53
extends DoubleDeadlineScenario {
    public Scenario53(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Vector2D terrainSize = new Vector2D(150.0, 150.0);
        Terrain terrain = Terrain.flat(terrainSize);
        List<Drone> drones = Arrays.asList(new Drone(new Vector3D(10.0, 0.0, 0.0), 2.0), new Drone(new Vector3D(100.0, 100.0, 0.0), 2.0));
        List<Parcel> parcels = Arrays.asList(new Parcel(0.0, terrain.translate(new Vector2D(10.0, 10.0)), terrain.translate(new Vector2D(50.0, 50.0))), new Parcel(0.0, terrain.translate(new Vector2D(150.0, 150.0)), terrain.translate(new Vector2D(100.0, 100.0))));
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline, parcels);
        if (simulation3D.isValid()) {
            return new DeliveryLevel(simulation3D);
        }
        throw new InternalError("Level creation failed");
    }
}

