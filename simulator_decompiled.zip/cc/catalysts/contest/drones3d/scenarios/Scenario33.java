/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.TargetLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.List;
import java.util.Vector;

public class Scenario33
extends DoubleDeadlineScenario {
    public Scenario33() {
    }

    public Scenario33(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Vector2D terrainSize = Vector2D.dia(200.0);
        Terrain terrain = Terrain.flat(terrainSize);
        Vector3D locA = new Vector3D(150.0, 150.0, 0.0);
        Vector3D locB = new Vector3D(50.0, 50.0, 0.0);
        Vector3D locC = new Vector3D(50.0, 150.0, 0.0);
        Vector<Drone> drones = new Vector<Drone>();
        Vector<Vector3D> targets = new Vector<Vector3D>();
        for (int i = 0; i < 17; ++i) {
            drones.add(new Drone(new Vector3D(20.0, 10 * i + 20, 0.0)));
            targets.add(new Vector3D(180.0, 180 - 10 * i, 0.0));
        }
        drones.add(new Drone(locA));
        drones.add(new Drone(locB));
        drones.add(new Drone(locC));
        targets.add(locB);
        targets.add(locC);
        targets.add(locA);
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline);
        if (simulation3D.isValid()) {
            return new TargetLevel(simulation3D, targets);
        }
        throw new InternalError("Level creation failed");
    }
}

