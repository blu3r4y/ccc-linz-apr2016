/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones.scenarios.Scenario;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.ClimbLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.util.Collections;
import java.util.List;

public class Scenario13
implements Scenario<Simulation3D> {
    private static final double SIZE = 20.0;
    private static final double DEADLINE = 10.0;

    @Override
    public Level<Simulation3D> initialize() {
        return new ClimbLevel(new Simulation3D(Terrain.flat(Vector2D.dia(20.0)), Collections.singletonList(new Drone(Vector2D.dia(10.0).toVector3D())), 10.0), 50.0);
    }
}

