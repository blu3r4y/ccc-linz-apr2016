/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.TargetLevel;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.Arrays;
import java.util.List;

public class Scenario32
extends DoubleDeadlineScenario {
    public Scenario32() {
    }

    public Scenario32(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Vector2D terrainSize = Vector2D.dia(50.0);
        Terrain terrain = Terrain.flat(terrainSize);
        Vector3D locA = new Vector3D(10.0, 10.0, 0.0);
        Vector3D locB = new Vector3D(40.0, 40.0, 0.0);
        List<Drone> drones = Arrays.asList(new Drone(locA), new Drone(locB));
        List<Vector3D> targets = Arrays.asList(locB, locA);
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline);
        if (simulation3D.isValid()) {
            return new TargetLevel(simulation3D, targets);
        }
        throw new InternalError("Level creation failed");
    }
}

