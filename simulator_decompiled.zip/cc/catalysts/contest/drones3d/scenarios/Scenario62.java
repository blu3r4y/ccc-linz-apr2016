/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.level.DeliveryLevel;
import cc.catalysts.contest.drones3d.map.ChargingStation;
import cc.catalysts.contest.drones3d.map.Terrain;
import cc.catalysts.contest.drones3d.scenarios.DoubleDeadlineScenario;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Scenario62
extends DoubleDeadlineScenario {
    public Scenario62(double deadline) {
        super(deadline);
    }

    @Override
    public Level<Simulation3D> initialize() {
        Terrain terrain = Terrain.flat(Vector2D.dia(180.0));
        List<Drone> drones = Collections.singletonList(new Drone(Vector2D.dia(5.0).toVector3D(), 2.0));
        List<Parcel> parcels = Arrays.asList(new Parcel(0.0, terrain.translate(new Vector2D(10.0, 10.0)), terrain.translate(new Vector2D(50.0, 50.0))), new Parcel(0.0, terrain.translate(new Vector2D(150.0, 150.0)), terrain.translate(new Vector2D(100.0, 100.0))));
        List<ChargingStation> chargingStations = Arrays.asList(new ChargingStation(terrain.translate(new Vector2D(50.0, 50.0)), 10), new ChargingStation(terrain.translate(new Vector2D(20.0, 30.0)), 10));
        Simulation3D simulation3D = new Simulation3D(terrain, drones, (Double)this.deadline, chargingStations, parcels);
        if (simulation3D.isValid()) {
            return new DeliveryLevel(simulation3D);
        }
        throw new InternalError("Level creation failed");
    }
}

