/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.scenarios;

import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

class ScenarioUtil {
    ScenarioUtil() {
    }

    static boolean safeLocationRaw(Vector3D l, List<Drone> ls) {
        for (Drone v : ls) {
            if (v.distanceTo(l) > 4.0) continue;
            return false;
        }
        return true;
    }

    static boolean safeLocationRaw(Vector3D l, Collection<Vector3D> ls) {
        for (Vector3D v : ls) {
            if (v.distanceTo(l) > 4.0) continue;
            return false;
        }
        return true;
    }

    private static boolean safe(List<Vector3D> s2, Vector3D l, double d) {
        for (Vector3D v : s2) {
            if (v.distanceTo(l) > d) continue;
            return false;
        }
        return true;
    }

    static List<Vector3D> randomAndSafe(Random rnd, Vector2D min2, Vector2D max, double safeDistance, Terrain t, int n) {
        ArrayList<Vector3D> ls = new ArrayList<Vector3D>(n);
        for (int i = 0; i < n; ++i) {
            Vector3D l;
            while (!ScenarioUtil.safe(ls, l = t.translate(new Vector2D(min2.x + rnd.nextDouble() * max.x, min2.y + rnd.nextDouble() * max.y)), safeDistance)) {
            }
            ls.add(l);
        }
        return ls;
    }

    static List<Drone> randomAndSafeDrones(Random rnd, Vector2D min2, Vector2D max, double safeDistance, Terrain t, int n) {
        List<Vector3D> locations = ScenarioUtil.randomAndSafe(rnd, min2, max, safeDistance, t, n);
        ArrayList<Drone> drones = new ArrayList<Drone>(locations.size());
        for (Vector3D l : locations) {
            drones.add(new Drone(l));
        }
        return drones;
    }
}

