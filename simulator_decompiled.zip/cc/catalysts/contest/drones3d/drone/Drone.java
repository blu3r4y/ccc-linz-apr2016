/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.drone;

import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Tickable;
import cc.catalysts.contest.drones3d.geometry.AxisAlignedBoundingBox;
import cc.catalysts.contest.drones3d.geometry.Intersectable;
import cc.catalysts.contest.drones3d.geometry.Ray;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.util.Collection;
import java.util.Stack;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Drone
implements Locatable,
Intersectable,
Tickable {
    private Vector3D l;
    private Vector3D v = new Vector3D();
    private Vector3D r = Vector3D.UP;
    private double battery;
    private double maxBattery;
    private double mass = 1.0;
    private double maxMass;
    private double throttle;
    private Stack<Parcel> parcels = new Stack();
    private boolean landed = true;
    private double fullChargeTime = 300.0;
    private boolean charging = false;
    public static final Vector3D G = Vector3D.z(9.80665);
    private static final Vector3D SIZE = new Vector3D(1.0, 1.0, 0.5);
    private static final int ROTOR_COUNT = 8;
    private static final double ROTOR_CONSTANT = 0.015;
    private static final double ROTOR_POWER_FACTOR = 3.2;
    private static final double ROTOR_MAX_RPM = 10000.0;
    private static final double ROTOR_DIAMETER = 0.25;
    private static final double AIR_DENSITY = 1.225;
    private static final double BATTERY_VOLTAGE = 12.0;
    private static final double SCAN_RANGE = 60.0;
    private static final double MAX_SPEED = 14.0;

    public Drone(Vector3D location, double maxMass, double flightDuration) {
        this.l = location;
        this.maxMass = maxMass;
        this.throttle = 1.0;
        this.battery = this.maxBattery = this.getPowerConsumed(flightDuration);
        this.throttle = 0.0;
    }

    public Drone(Vector3D location, double maxMass) {
        this(location, maxMass, Double.POSITIVE_INFINITY);
    }

    public Drone(Vector3D location) {
        this(location, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
    }

    public Drone() {
        this(new Vector3D());
    }

    private double getPower() {
        return 0.015 * Math.pow(10.0 * this.throttle, 3.2);
    }

    private double getPowerConsumed(double dt) {
        return this.getPower() * 8.0 / (3600.0 / dt) / 12.0 * 1000.0;
    }

    private double thrust(double dt) {
        return Math.cbrt(1.5707963267948966 * Math.pow(0.25, 2.0) * 1.225 * Math.pow(this.getPower(), 2.0)) * 8.0;
    }

    private void updateBattery(double dt) {
        this.battery -= this.getPowerConsumed(dt);
        if (this.battery <= 0.0) {
            throw new IllegalStateException("Battery empty");
        }
    }

    @Override
    public void tick(double dt) {
        if (this.charging) {
            if (this.throttle > 0.0) {
                throw new IllegalStateException("Throttle must be zero during charging");
            }
            this.battery = Math.min(this.maxBattery, this.battery + dt / this.fullChargeTime * this.maxBattery);
            this.charging = false;
            return;
        }
        this.updateBattery(dt);
        Vector3D vnew = this.v.add(this.r.mul(this.thrust(dt) / this.mass / this.r.mag()).sub(G).mul(dt));
        if (this.landed && vnew.z <= 0.0) {
            return;
        }
        this.landed = false;
        this.l = this.l.add(this.v.add(vnew).mul(dt / 2.0));
        this.v = vnew;
        if (this.v.mag() > 14.0) {
            throw new IllegalStateException("Drone exceeded the speed limit");
        }
    }

    public void liftParcel(Parcel parcel) {
        if (parcel.getMass() + this.mass > this.maxMass) {
            throw new IllegalArgumentException("Parcel too heavy!");
        }
        this.parcels.push(parcel);
        parcel.link(this);
        this.mass += parcel.getMass();
    }

    public Parcel dropParcel() {
        if (!this.landed) {
            throw new IllegalStateException("Drone must have landed.");
        }
        if (this.parcels.isEmpty()) {
            throw new IllegalStateException("Drone does not carry any parcel.");
        }
        Parcel parcel = this.parcels.pop();
        parcel.unlink();
        this.mass -= parcel.getMass();
        return parcel;
    }

    public void rotate(Vector3D dr) {
        Vector3D r = this.r.add(dr);
        if (r.mag() == 0.0) {
            throw new IllegalArgumentException("The rotation vector cannot be changed to have a magnitude of zero.");
        }
        this.r = r;
    }

    public double scan(Vector3D d, Collection<Intersectable> intersectables) {
        if (d.mag() == 0.0) {
            throw new IllegalArgumentException("Direction vector has magnitude zero, it does not point anywhere!");
        }
        Ray ray = new Ray(this.l, d.normalize());
        double minDepth = 60.0;
        for (Intersectable i : intersectables) {
            double depth = i.intersects(ray);
            if (depth <= 0.0 || depth >= 60.0) continue;
            minDepth = Math.min(minDepth, depth);
        }
        return minDepth;
    }

    public void land(Terrain terrain) {
        if (this.throttle > 0.0) {
            throw new IllegalStateException("Drone throttle greater than zero (" + this.throttle + " > 0.0).");
        }
        double tmp = Math.abs(this.v.z);
        if (tmp > 0.5) {
            throw new IllegalStateException("Drone velocity parallel to z-axis is too high (" + tmp + " > 0.5).");
        }
        tmp = terrain.distanceTo(this);
        if (tmp > 0.3) {
            throw new IllegalStateException("Drone is too far from ground (" + tmp + " > 0.3).");
        }
        tmp = this.v.mag();
        if (tmp > 5.0) {
            throw new IllegalStateException("Drone's velocity is too high (" + tmp + " > 5.0).");
        }
        this.v = new Vector3D();
        this.l = terrain.translate(this.l.toVector2D());
        this.landed = true;
    }

    public boolean collidesWith(AxisAlignedBoundingBox box) {
        return this.getShape().collidesWith(box);
    }

    public void setThrottle(double throttle) {
        if (throttle < 0.0 || throttle > 1.0) {
            throw new IllegalArgumentException();
        }
        this.throttle = throttle;
    }

    @Override
    public Vector3D getLocation() {
        return this.l;
    }

    @Override
    public double distanceTo(Locatable o) {
        return this.distanceTo(o.getLocation());
    }

    @Override
    public double distanceTo(Vector3D v) {
        return this.getLocation().distanceTo(v);
    }

    public Vector3D getRotation() {
        return this.r;
    }

    public AxisAlignedBoundingBox getShape() {
        return new AxisAlignedBoundingBox(new Vector3D(this.l.x - Drone.SIZE.x / 2.0, this.l.y - Drone.SIZE.y / 2.0, this.l.z - Drone.SIZE.z / 2.0), new Vector3D(this.l.x + Drone.SIZE.x / 2.0, this.l.y + Drone.SIZE.y / 2.0, this.l.z + Drone.SIZE.z / 2.0));
    }

    public double getThrottle() {
        return this.throttle;
    }

    public void chargeBattery(double charge) {
        this.battery = Math.max(this.battery + charge, this.maxBattery);
    }

    public Vector3D getVelocity() {
        return this.v;
    }

    public boolean notMoving() {
        return this.v.mag() < 0.01;
    }

    @SideEffectFree
    public String toString() {
        return this.l + " " + this.v + " " + this.r;
    }

    public boolean hasLanded() {
        return this.landed;
    }

    @Override
    public double intersects(Ray r) {
        return this.getShape().intersects(r);
    }

    public double getCapacity() {
        return this.maxMass - this.mass;
    }

    public double getRelativeBattery() {
        return this.battery / this.maxBattery;
    }

    public void charge() {
        this.charging = true;
    }
}

