/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.level;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.map.ChargingStation;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.io.PrintWriter;
import java.util.List;

public class DeliveryLevel
extends Level<Simulation3D> {
    public DeliveryLevel(Simulation3D simulation) {
        super(simulation);
    }

    @Override
    public boolean success() {
        for (Parcel p : ((Simulation3D)this.simulation).getParcels()) {
            if (p.isDelivered()) continue;
            return false;
        }
        return true;
    }

    @Override
    public void init(PrintWriter out) {
        Vector2D size = ((Simulation3D)this.simulation).getTerrain().getSize();
        out.println("0.0 " + size.x + " 0.0 " + size.y);
        out.println("" + ((Simulation3D)this.simulation).getDrones().size() + " " + ((Simulation3D)this.simulation).getParcels().size() + (((Simulation3D)this.simulation).getChargingStations().size() > 0 ? new StringBuilder().append(" ").append(((Simulation3D)this.simulation).getChargingStations().size()).toString() : ""));
        for (Drone d : ((Simulation3D)this.simulation).getDrones()) {
            out.println(d.getCapacity());
        }
        for (Parcel p : ((Simulation3D)this.simulation).getParcels()) {
            out.println(p);
        }
        for (ChargingStation s2 : ((Simulation3D)this.simulation).getChargingStations()) {
            out.println(s2);
        }
        out.println(((Simulation3D)this.simulation).getDeadline());
    }
}

