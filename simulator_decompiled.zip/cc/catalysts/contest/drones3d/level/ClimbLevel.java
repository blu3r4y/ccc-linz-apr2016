/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.level;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.io.PrintWriter;
import java.util.List;

public class ClimbLevel
extends Level<Simulation3D> {
    private static final double DEFAULT_HEIGHT = 10.0;
    private final double height;

    public ClimbLevel(Simulation3D simulation, double height) {
        super(simulation);
        this.height = height;
    }

    @Override
    public boolean success() {
        for (Drone d : ((Simulation3D)this.simulation).getDrones()) {
            if (((Simulation3D)this.simulation).getTerrain().distanceTo(d) >= this.height) continue;
            return false;
        }
        return true;
    }

    @Override
    public void init(PrintWriter out) {
        Vector2D size = ((Simulation3D)this.simulation).getTerrain().getSize();
        out.println("0.0 " + size.x + " 0.0 " + size.y);
        out.println(((Simulation3D)this.simulation).getDrones().size());
        out.println(this.height);
    }
}

