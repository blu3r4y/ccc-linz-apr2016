/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.level;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.io.PrintWriter;
import java.util.List;

public class HoverLevel
extends Level<Simulation3D> {
    private double hoverStart = Double.NaN;
    private static final double MIN_HEIGHT = 20.0;
    private static final double MAX_HEIGHT = 40.0;
    private static final double HOVER_DURATION = 10.0;

    public HoverLevel(Simulation3D simulation) {
        super(simulation);
    }

    @Override
    public boolean success() {
        double t = ((Simulation3D)this.simulation).getTime();
        boolean allAirborne = true;
        for (Drone d2 : ((Simulation3D)this.simulation).getDrones()) {
            double height = ((Simulation3D)this.simulation).getTerrain().distanceTo(d2);
            if (height <= 40.0 && height >= 20.0) continue;
            allAirborne = false;
            break;
        }
        if (allAirborne) {
            if (Double.isNaN(this.hoverStart)) {
                this.hoverStart = t;
                return false;
            }
        } else if (t - this.hoverStart < 10.0) {
            this.hoverStart = Double.NaN;
            return false;
        }
        if (Double.isNaN(this.hoverStart) || t - this.hoverStart < 10.0) {
            return false;
        }
        for (Drone d2 : ((Simulation3D)this.simulation).getDrones()) {
            if (d2.hasLanded()) continue;
            return false;
        }
        return true;
    }

    @Override
    public void init(PrintWriter out) {
        Vector2D size = ((Simulation3D)this.simulation).getTerrain().getSize();
        out.println("0.0 " + size.x + " 0.0 " + size.y);
        out.println(((Simulation3D)this.simulation).getDrones().size());
    }
}

