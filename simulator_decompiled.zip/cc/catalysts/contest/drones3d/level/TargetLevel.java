/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.level;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.io.PrintWriter;
import java.util.List;

public class TargetLevel
extends Level<Simulation3D> {
    private final double MAX_DISTANCE = 2.0;
    private final List<Vector3D> targets;

    public TargetLevel(Simulation3D simulation, List<Vector3D> targets) {
        super(simulation);
        this.targets = targets;
        if (simulation.getDrones().size() != targets.size()) {
            throw new IllegalArgumentException("Number of targets must equal number of drones.");
        }
    }

    @Override
    public boolean success() {
        for (int i = 0; i < this.targets.size(); ++i) {
            if (((Simulation3D)this.simulation).getDrones().get(i).getLocation().distanceTo(this.targets.get(i)) >= 2.0) {
                return false;
            }
            if (((Simulation3D)this.simulation).getDrones().get(i).hasLanded()) continue;
            return false;
        }
        return true;
    }

    @Override
    public void init(PrintWriter out) {
        Vector2D size = ((Simulation3D)this.simulation).getTerrain().getSize();
        out.println("0.0 " + size.x + " 0.0 " + size.y);
        out.println(((Simulation3D)this.simulation).getDrones().size());
        for (Vector3D t : this.targets) {
            out.println(t);
        }
        if (!Double.isInfinite(((Simulation3D)this.simulation).getDeadline())) {
            out.println(((Simulation3D)this.simulation).getDeadline());
        }
    }
}

