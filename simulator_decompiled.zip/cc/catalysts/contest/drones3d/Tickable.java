/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

public interface Tickable {
    public void tick(double var1);
}

