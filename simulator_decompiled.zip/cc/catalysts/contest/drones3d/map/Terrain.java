/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.map;

import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.geometry.Intersectable;
import cc.catalysts.contest.drones3d.geometry.Ray;
import cc.catalysts.contest.drones3d.geometry.Triangle;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import com.google.common.base.Optional;
import java.util.LinkedList;
import java.util.List;

public class Terrain
implements Intersectable {
    private List<Triangle> triangles = new LinkedList<Triangle>();
    private final Vector2D size;

    public static Terrain flat(Vector2D size) {
        return Terrain.slope(size, 0.0, 0.0, 0.0);
    }

    public static Terrain flat() {
        return Terrain.flat(new Vector2D());
    }

    public static Terrain slope(Vector2D size, double zOrigin, double dzDirX, double dzDirY) {
        Terrain t = new Terrain(size);
        Vector3D v00 = new Vector3D(0.0, 0.0, zOrigin);
        Vector3D vx0 = new Vector3D(size.x, 0.0, zOrigin + dzDirX);
        Vector3D v0y = new Vector3D(0.0, size.y, zOrigin + dzDirY);
        Vector3D vxy = new Vector3D(size.x, size.y, zOrigin + dzDirX + dzDirY);
        t.triangles.add(new Triangle(v00, vx0, vxy));
        t.triangles.add(new Triangle(vxy, v0y, v00));
        return t;
    }

    public Terrain(Vector2D size) {
        this.size = size;
    }

    public double distanceTo(Locatable l) {
        return l.getLocation().z - this.translate((Vector2D)l.getLocation().toVector2D()).z;
    }

    public Vector3D translate(Vector2D v) {
        for (Triangle t : this.triangles) {
            Optional<Vector3D> d = t.translate(v, 0.001);
            if (!d.isPresent()) continue;
            return d.get();
        }
        throw new IllegalArgumentException("Vector " + v + " could not be translated!");
    }

    @Override
    public double intersects(Ray ray) {
        for (Triangle t : this.triangles) {
            double d = t.intersects(ray);
            if (Double.isInfinite(d)) continue;
            return d;
        }
        return Double.POSITIVE_INFINITY;
    }

    public Vector2D getSize() {
        return this.size;
    }
}

