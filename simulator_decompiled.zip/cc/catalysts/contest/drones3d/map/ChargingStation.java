/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.map;

import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class ChargingStation
implements Locatable {
    private final double chargePerSecond;
    private final Vector3D l;

    public ChargingStation(Vector3D location, int chargePerSecond) {
        this.l = location;
        this.chargePerSecond = chargePerSecond;
    }

    public ChargingStation(Vector3D position) {
        this(position, 10);
    }

    public double getChargePerSecond() {
        return this.chargePerSecond;
    }

    @Override
    public Vector3D getLocation() {
        return this.l;
    }

    @Override
    public double distanceTo(Locatable o) {
        return this.distanceTo(o.getLocation());
    }

    @Override
    public double distanceTo(Vector3D v) {
        return this.getLocation().distanceTo(v);
    }

    @SideEffectFree
    public String toString() {
        return this.l.toVector2D().toString();
    }
}

