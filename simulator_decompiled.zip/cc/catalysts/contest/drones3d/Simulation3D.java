/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones.Simulation;
import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Tickable;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.AxisAlignedBoundingBox;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.map.ChargingStation;
import cc.catalysts.contest.drones3d.map.Terrain;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Simulation3D
implements Tickable,
Simulation {
    private static final double CHARGING_DISTANCE = 5.0;
    private final List<Drone> drones;
    private final List<Parcel> parcels;
    private final List<ChargingStation> chargingStations;
    private final List<AxisAlignedBoundingBox> obstacles;
    private final Terrain terrain;
    private final double deadline;
    private double t = 0.0;

    public Simulation3D(Terrain terrain, List<Drone> drones, double deadline, List<AxisAlignedBoundingBox> obstacles, List<Parcel> parcels, List<ChargingStation> chargingStations) {
        this.terrain = terrain;
        this.drones = Collections.unmodifiableList(drones);
        this.deadline = deadline;
        this.obstacles = Collections.unmodifiableList(obstacles);
        this.parcels = Collections.unmodifiableList(parcels);
        this.chargingStations = Collections.unmodifiableList(chargingStations);
    }

    public Simulation3D(Terrain terrain, List<Drone> drones, double deadline, List<ChargingStation> chargingStations, List<Parcel> parcels) {
        this(terrain, drones, deadline, Collections.emptyList(), parcels, chargingStations);
    }

    public Simulation3D(Terrain terrain, List<Drone> drones, double deadline, List<Parcel> parcels) {
        this(terrain, drones, deadline, Collections.emptyList(), parcels, Collections.emptyList());
    }

    public Simulation3D(Terrain terrain, List<Drone> drones, double deadline) {
        this(terrain, drones, deadline, Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
    }

    public Simulation3D(Terrain terrain, List<Drone> drones) {
        this(terrain, drones, Double.POSITIVE_INFINITY, Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
    }

    public boolean checkCollisions() {
        for (int i = 0; i < this.drones.size(); ++i) {
            for (int j = 0; j < i; ++j) {
                if (!this.drones.get(i).collidesWith(this.drones.get(j).getShape())) continue;
                throw new IllegalStateException("Drone " + i + " collided with drone " + j + ".");
            }
        }
        return false;
    }

    public void updateDrones(double dt) {
        if (this.checkCollisions()) {
            return;
        }
        for (Drone d : this.drones) {
            d.tick(dt);
        }
    }

    private boolean inRange(Locatable a, Locatable b) {
        return a.distanceTo(b) <= 1.0;
    }

    public List<Drone> getDrones() {
        return this.drones;
    }

    @Override
    public void tick(double dt) {
        if (dt == 0.0) {
            return;
        }
        if (dt < 0.0) {
            throw new IllegalArgumentException("dt must not be negative: " + dt);
        }
        this.updateDrones(dt);
        for (int i = 0; i < this.drones.size(); ++i) {
            Drone drone = this.drones.get(i);
            Vector3D l = drone.getLocation();
            if (l.x < 0.0 || l.y < 0.0 || l.y > this.terrain.getSize().y || l.x > this.terrain.getSize().x) {
                throw new IllegalStateException("Drone " + i + " left map (" + l + " is not between 0 0 and " + this.terrain.getSize() + " inclusive).");
            }
            if (this.terrain.distanceTo(drone) < 0.0) {
                throw new IllegalStateException("Drone " + i + " crashed into ground.");
            }
            for (int j = 0; j < this.obstacles.size(); ++j) {
                if (!drone.collidesWith(this.obstacles.get(j))) continue;
                throw new IllegalStateException("Drone " + i + " collided with obstacle.");
            }
        }
        this.t += dt;
        if (this.t > this.deadline) {
            throw new IllegalStateException("Simulation timed out.");
        }
    }

    public List<Parcel> getParcelsInRange(Locatable l) {
        ArrayList<Parcel> result = new ArrayList<Parcel>();
        for (Parcel p : this.parcels) {
            if (p.isLinked() || !this.inRange(p, l)) continue;
            result.add(p);
        }
        return result;
    }

    public List<Parcel> getParcels() {
        return this.parcels;
    }

    public List<ChargingStation> getChargingStationsInRange(Locatable l) {
        ArrayList<ChargingStation> result = new ArrayList<ChargingStation>();
        for (ChargingStation s2 : this.chargingStations) {
            if (l.distanceTo(s2) > 5.0) continue;
            result.add(s2);
        }
        return result;
    }

    public boolean isValid() {
        for (Drone drone3 : this.drones) {
            if (this.terrain.distanceTo(drone3) >= 0.0) continue;
            return false;
        }
        for (Parcel parcel : this.parcels) {
            if (this.terrain.distanceTo(parcel) >= 0.0) continue;
            return false;
        }
        for (ChargingStation chargingStation2 : this.chargingStations) {
            if (this.terrain.distanceTo(chargingStation2) >= 0.0) continue;
            return false;
        }
        if (!this.chargingStations.isEmpty()) {
            for (ChargingStation chargingStation2 : this.chargingStations) {
                for (Drone drone2 : this.drones) {
                    if (drone2.distanceTo(chargingStation2) >= 1.0) continue;
                    return false;
                }
            }
        }
        if (!this.obstacles.isEmpty()) {
            for (Drone drone3 : this.drones) {
                for (AxisAlignedBoundingBox obstacle : this.obstacles) {
                    if (!drone3.collidesWith(obstacle)) continue;
                    return false;
                }
            }
        }
        if (!this.parcels.isEmpty()) {
            for (Drone drone3 : this.drones) {
                for (Parcel parcel2 : this.parcels) {
                    if (drone3.distanceTo(parcel2) >= 2.0) continue;
                    return false;
                }
            }
        }
        return true;
    }

    public double getTime() {
        return this.t;
    }

    public Terrain getTerrain() {
        return this.terrain;
    }

    public List<AxisAlignedBoundingBox> getObstacles() {
        return this.obstacles;
    }

    public double getDeadline() {
        return this.deadline;
    }

    public List<ChargingStation> getChargingStations() {
        return this.chargingStations;
    }
}

