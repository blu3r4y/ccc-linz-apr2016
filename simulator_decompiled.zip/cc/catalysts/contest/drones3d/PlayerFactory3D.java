/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones.AbstractPlayer;
import cc.catalysts.contest.drones.PlayerFactory;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Player;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.scenarios.Scenario11;
import cc.catalysts.contest.drones3d.scenarios.Scenario12;
import cc.catalysts.contest.drones3d.scenarios.Scenario13;
import cc.catalysts.contest.drones3d.scenarios.Scenario21;
import cc.catalysts.contest.drones3d.scenarios.Scenario22;
import cc.catalysts.contest.drones3d.scenarios.Scenario23;
import cc.catalysts.contest.drones3d.scenarios.Scenario31;
import cc.catalysts.contest.drones3d.scenarios.Scenario32;
import cc.catalysts.contest.drones3d.scenarios.Scenario33;
import cc.catalysts.contest.drones3d.scenarios.Scenario41;
import cc.catalysts.contest.drones3d.scenarios.Scenario42;
import cc.catalysts.contest.drones3d.scenarios.Scenario43;
import cc.catalysts.contest.drones3d.scenarios.Scenario51;
import cc.catalysts.contest.drones3d.scenarios.Scenario52;
import cc.catalysts.contest.drones3d.scenarios.Scenario53;
import cc.catalysts.contest.drones3d.scenarios.Scenario61;
import cc.catalysts.contest.drones3d.scenarios.Scenario62;
import cc.catalysts.contest.drones3d.scenarios.Scenario63;
import cc.catalysts.contest.drones3d.scenarios.Scenario71;
import cc.catalysts.contest.drones3d.scenarios.Scenario72;
import cc.catalysts.contest.drones3d.scenarios.Scenario73;
import java.io.OutputStream;
import java.util.Scanner;

class PlayerFactory3D
implements PlayerFactory<Simulation3D> {
    PlayerFactory3D() {
    }

    public Player getPlayer(int l, int t, OutputStream out, Scanner sc) {
        return new Player(this.getLevel(l, t), out, sc);
    }

    private Level<Simulation3D> getLevel(int l, int t) {
        if (l == 1 && t == 1) {
            return new Scenario11().initialize();
        }
        if (l == 1 && t == 2) {
            return new Scenario12().initialize();
        }
        if (l == 1 && t == 3) {
            return new Scenario13().initialize();
        }
        if (l == 2 && t == 1) {
            return new Scenario21().initialize();
        }
        if (l == 2 && t == 2) {
            return new Scenario22().initialize();
        }
        if (l == 2 && t == 3) {
            return new Scenario23().initialize();
        }
        if (l == 3 && t == 1) {
            return new Scenario31().initialize();
        }
        if (l == 3 && t == 2) {
            return new Scenario32().initialize();
        }
        if (l == 3 && t == 3) {
            return new Scenario33().initialize();
        }
        if (l == 4 && t == 1) {
            return new Scenario41().initialize();
        }
        if (l == 4 && t == 2) {
            return new Scenario42().initialize();
        }
        if (l == 4 && t == 3) {
            return new Scenario43().initialize();
        }
        if (l == 5 && t == 1) {
            return new Scenario51(3600.0).initialize();
        }
        if (l == 5 && t == 2) {
            return new Scenario52(7200.0).initialize();
        }
        if (l == 5 && t == 3) {
            return new Scenario53(10800.0).initialize();
        }
        if (l == 6 && t == 1) {
            return new Scenario61(3600.0).initialize();
        }
        if (l == 6 && t == 2) {
            return new Scenario62(7200.0).initialize();
        }
        if (l == 6 && t == 3) {
            return new Scenario63(10800.0).initialize();
        }
        if (l == 7 && t == 1) {
            return new Scenario71(3600.0).initialize();
        }
        if (l == 7 && t == 2) {
            return new Scenario72(7200.0).initialize();
        }
        if (l == 7 && t == 3) {
            return new Scenario73(10800.0).initialize();
        }
        throw new IllegalArgumentException();
    }
}

