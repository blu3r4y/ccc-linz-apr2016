/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones.AbstractPlayer;
import cc.catalysts.contest.drones.level.Level;
import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.Parcel;
import cc.catalysts.contest.drones3d.Simulation3D;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.AxisAlignedBoundingBox;
import cc.catalysts.contest.drones3d.geometry.Intersectable;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import cc.catalysts.contest.drones3d.map.ChargingStation;
import cc.catalysts.contest.drones3d.map.Terrain;
import com.google.common.base.Optional;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

final class Player
extends AbstractPlayer<Simulation3D> {
    Player(Level<Simulation3D> level, OutputStream out, Scanner sc) {
        super(level, out, sc);
    }

    private Drone nextDrone() {
        return ((Simulation3D)this.level.getSimulation()).getDrones().get(this.sc.nextInt());
    }

    private Vector3D nextVector3D() {
        return new Vector3D(this.sc.nextDouble(), this.sc.nextDouble(), this.sc.nextDouble());
    }

    @Override
    protected Optional<Boolean> dispatchCommand(String command) {
        switch (command) {
            case "status": {
                this.out.println(this.nextDrone());
                break;
            }
            case "battery": {
                this.out.println(100.0 * this.nextDrone().getRelativeBattery());
            }
            case "throttle": {
                this.nextDrone().setThrottle(this.sc.nextDouble());
                this.ok();
                break;
            }
            case "turn": {
                this.nextDrone().rotate(this.nextVector3D());
                this.ok();
                break;
            }
            case "tick": {
                return this.tick(this.sc.nextDouble()) ? Optional.of(true) : Optional.absent();
            }
            case "pick": {
                this.pick(this.nextDrone());
                break;
            }
            case "drop": {
                this.nextDrone().dropParcel();
                this.ok();
                break;
            }
            case "charge": {
                this.charge(this.nextDrone());
                break;
            }
            case "land": {
                this.nextDrone().land(((Simulation3D)this.level.getSimulation()).getTerrain());
                this.ok();
                break;
            }
            case "scan": {
                this.scan(this.nextDrone(), this.nextVector3D());
                break;
            }
            default: {
                throw new InputMismatchException();
            }
        }
        return Optional.absent();
    }

    private void scan(Drone drone, Vector3D direction) {
        ArrayList<Intersectable> intersectables = new ArrayList<Intersectable>();
        intersectables.addAll(((Simulation3D)this.level.getSimulation()).getObstacles());
        intersectables.addAll(((Simulation3D)this.level.getSimulation()).getDrones());
        intersectables.add(((Simulation3D)this.level.getSimulation()).getTerrain());
        this.out.println(drone.scan(direction, intersectables));
    }

    private void pick(Drone drone) {
        List<Parcel> parcel = ((Simulation3D)this.level.getSimulation()).getParcelsInRange(drone);
        if (parcel.isEmpty()) {
            throw new IllegalStateException("no parcel close to drone");
        }
        if (parcel.size() > 1) {
            throw new IllegalStateException("more than one parcel close to drone");
        }
        drone.liftParcel(parcel.get(0));
        this.ok();
    }

    private void charge(Drone drone) {
        List<ChargingStation> stations = ((Simulation3D)this.level.getSimulation()).getChargingStationsInRange(drone);
        if (!drone.hasLanded()) {
            throw new IllegalStateException("Drone must have landed.");
        }
        if (stations.isEmpty()) {
            throw new IllegalStateException("Drone not close enough to a charging station");
        }
        drone.charge();
        this.ok();
    }

    private boolean tick(double dt) {
        ((Simulation3D)this.level.getSimulation()).tick(dt);
        if (this.level.success()) {
            this.out.println("SUCCESS");
            return true;
        }
        this.out.println(((Simulation3D)this.level.getSimulation()).getTime());
        return false;
    }
}

