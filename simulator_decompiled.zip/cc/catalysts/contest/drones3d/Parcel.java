/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones.Linkable;
import cc.catalysts.contest.drones3d.Locatable;
import cc.catalysts.contest.drones3d.drone.Drone;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Parcel
extends Linkable<Drone>
implements Locatable {
    private final double m;
    private final Vector3D d;
    private Vector3D l;
    private Vector3D v;
    private static final double PICKUP_DISTANCE = 1.0;
    private static final double DELIVERY_DISTANCE = 5.0;

    public Parcel(double mass, Vector3D location, Vector3D destination) {
        this.m = mass;
        this.d = destination;
        this.l = location;
    }

    public Vector3D getDestination() {
        return this.d;
    }

    public double getMass() {
        return this.m;
    }

    @Override
    public Vector3D getLocation() {
        if (this.isLinked()) {
            return ((Drone)this.getLink()).getLocation();
        }
        return this.l;
    }

    @Override
    public double distanceTo(Locatable o) {
        return this.distanceTo(o.getLocation());
    }

    @Override
    public double distanceTo(Vector3D v) {
        return this.getLocation().distanceTo(v);
    }

    @Override
    public void unlink() {
        this.l = ((Drone)this.getLink()).getLocation();
        super.unlink();
    }

    public boolean isDelivered() {
        return this.distanceTo(this.d) <= 5.0 && !this.isLinked();
    }

    public boolean isCloseTo(Locatable l) {
        return this.distanceTo(l) <= 1.0;
    }

    @SideEffectFree
    public String toString() {
        return "" + this.m + " " + this.l.toVector2D() + " " + this.d.toVector2D();
    }
}

