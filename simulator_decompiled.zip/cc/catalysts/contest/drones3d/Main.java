/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones.PlayerFactory;
import cc.catalysts.contest.drones.Simulator;
import cc.catalysts.contest.drones3d.PlayerFactory3D;

public class Main {
    public static void main(String[] args) throws Exception {
        new Simulator(new PlayerFactory3D()).run(args);
    }
}

