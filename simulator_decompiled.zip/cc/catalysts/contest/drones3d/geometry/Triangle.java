/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Intersectable;
import cc.catalysts.contest.drones3d.geometry.Ray;
import cc.catalysts.contest.drones3d.geometry.Vector2D;
import cc.catalysts.contest.drones3d.geometry.Vector3D;
import com.google.common.base.Optional;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Triangle
implements Intersectable {
    private final Vector3D p1;
    private final Vector3D p2;
    private final Vector3D p3;
    private final Vector3D n;
    private final double a;
    private final Vector2D min2D;
    private final Vector2D max2D;
    private final double h1proj;
    private final double h2proj;
    private final double h3proj;
    private static final double SMALL_NUM = 1.0E-7;

    public Triangle(Vector3D p1, Vector3D p2, Vector3D p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.n = p2.sub(p1).cross(p3.sub(p1));
        this.a = 0.5 * this.n.mag();
        this.min2D = new Vector2D(Math.min(Math.min(p1.x, p2.x), p3.x), Math.min(Math.min(p1.y, p2.y), p3.y));
        this.max2D = new Vector2D(Math.max(Math.max(p1.x, p2.x), p3.x), Math.max(Math.max(p1.y, p2.y), p3.y));
        this.h1proj = 2.0 * this.a / new Vector2D(p3.x - p2.x, p3.y - p2.y).mag();
        this.h2proj = 2.0 * this.a / new Vector2D(p1.x - p3.x, p1.y - p3.y).mag();
        this.h3proj = 2.0 * this.a / new Vector2D(p2.x - p1.x, p2.y - p1.y).mag();
    }

    @Override
    public double intersects(Ray ray) {
        if (this.n.mag() == 0.0) {
            return Double.POSITIVE_INFINITY;
        }
        double rNum = - this.n.dot(ray.p.sub(this.p1));
        double rDen = this.n.dot(ray.d);
        if (Math.abs(rDen) < 1.0E-7) {
            return Double.POSITIVE_INFINITY;
        }
        double r = rNum / rDen;
        Vector3D p = ray.p.add(ray.d.mul(r));
        Triangle t1 = new Triangle(this.p1, this.p2, p);
        Triangle t2 = new Triangle(this.p2, this.p3, p);
        Triangle t3 = new Triangle(this.p1, this.p3, p);
        if (t1.a + t2.a + t3.a - this.a > 1.0E-7) {
            return Double.POSITIVE_INFINITY;
        }
        return r;
    }

    public Optional<Vector3D> translate(Vector2D p, double thickness) {
        if (p.x < this.min2D.x - thickness || p.x > this.max2D.x + thickness || p.y < this.min2D.y - thickness || p.y > this.max2D.y + thickness) {
            return Optional.absent();
        }
        double det = (this.p2.y - this.p3.y) * (this.p1.x - this.p3.x) + (this.p3.x - this.p2.x) * (this.p1.y - this.p3.y);
        double b1 = ((this.p2.y - this.p3.y) * (p.x - this.p3.x) + (this.p3.x - this.p2.x) * (p.y - this.p3.y)) / det;
        double b2 = ((p.y - this.p3.y) * (this.p1.x - this.p3.x) + (this.p3.x - p.x) * (this.p1.y - this.p3.y)) / det;
        double b3 = 1.0 - b1 - b2;
        if (b1 * this.h1proj < - thickness || b2 * this.h2proj < - thickness || b3 * this.h3proj < - thickness) {
            return Optional.absent();
        }
        return Optional.of(new Vector3D(p.x, p.y, b1 * this.p1.z + b2 * this.p2.z + b3 * this.p3.z));
    }

    @SideEffectFree
    public String toString() {
        return this.p1 + " " + this.p2 + " " + this.p3;
    }
}

