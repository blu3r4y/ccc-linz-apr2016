/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Vector2D;
import org.checkerframework.dataflow.qual.Pure;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Vector3D {
    public final double x;
    public final double y;
    public final double z;
    public static final Vector3D DOWN = Vector3D.z(-1.0);
    public static final Vector3D UP = Vector3D.z(1.0);

    public Vector3D() {
        this(0.0, 0.0, 0.0);
    }

    public Vector3D(Vector3D v) {
        this(v.x, v.y, v.z);
    }

    public Vector3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public static Vector3D x(double x) {
        return new Vector3D(x, 0.0, 0.0);
    }

    public static Vector3D y(double y) {
        return new Vector3D(0.0, y, 0.0);
    }

    public static Vector3D z(double z) {
        return new Vector3D(0.0, 0.0, z);
    }

    public double distanceTo(Vector3D v) {
        return Math.sqrt(Math.pow(this.x - v.x, 2.0) + Math.pow(this.y - v.y, 2.0) + Math.pow(this.z - v.z, 2.0));
    }

    public Vector3D add(Vector3D v) {
        return new Vector3D(this.x + v.x, this.y + v.y, this.z + v.z);
    }

    public Vector3D mul(double v) {
        return new Vector3D(this.x * v, this.y * v, this.z * v);
    }

    public Vector3D sub(Vector3D v) {
        return new Vector3D(this.x - v.x, this.y - v.y, this.z - v.z);
    }

    public double dot(Vector3D v) {
        return this.x * v.x + this.y * v.y + this.z * v.z;
    }

    public Vector3D normalize() {
        return this.mul(1.0 / this.mag());
    }

    public Vector3D inv() {
        return new Vector3D(1.0 / this.x, 1.0 / this.y, 1.0 / this.z);
    }

    public double mag() {
        return Math.sqrt(Math.pow(this.x, 2.0) + Math.pow(this.y, 2.0) + Math.pow(this.z, 2.0));
    }

    public Vector3D cross(Vector3D v) {
        return new Vector3D(this.y * v.z - v.y * this.z, this.z * v.x - v.z * this.x, this.x * v.y - v.x * this.y);
    }

    public Vector2D toVector2D() {
        return new Vector2D(this.x, this.y);
    }

    @SideEffectFree
    public String toString() {
        return "" + this.x + " " + this.y + " " + this.z;
    }

    @Pure
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Vector3D v = (Vector3D)o;
        return Double.compare(v.x, this.x) == 0 && Double.compare(v.y, this.y) == 0 && Double.compare(v.z, this.z) == 0;
    }

    @Pure
    public int hashCode() {
        long temp = Double.doubleToLongBits(this.x);
        int result = (int)(temp ^ temp >>> 32);
        temp = Double.doubleToLongBits(this.y);
        result = 31 * result + (int)(temp ^ temp >>> 32);
        temp = Double.doubleToLongBits(this.z);
        result = 31 * result + (int)(temp ^ temp >>> 32);
        return result;
    }
}

