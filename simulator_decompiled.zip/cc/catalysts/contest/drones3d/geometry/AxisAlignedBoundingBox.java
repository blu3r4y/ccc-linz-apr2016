/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Intersectable;
import cc.catalysts.contest.drones3d.geometry.Ray;
import cc.catalysts.contest.drones3d.geometry.Vector3D;

public class AxisAlignedBoundingBox
implements Intersectable {
    private Vector3D min;
    private Vector3D max;

    public AxisAlignedBoundingBox(Vector3D min2, Vector3D max) {
        this.max = max;
        this.min = min2;
    }

    public boolean collidesWith(AxisAlignedBoundingBox box) {
        return this.max.x > box.min.x && this.min.x < box.max.x && this.max.y > box.min.y && this.min.y < box.max.y && this.max.z > box.min.z && this.min.z < box.max.z;
    }

    @Override
    public double intersects(Ray r) {
        double tx1 = (this.min.x - r.p.x) * r.inv.x;
        double tx2 = (this.max.x - r.p.x) * r.inv.x;
        double tmin = Math.min(tx1, tx2);
        double tmax = Math.max(tx1, tx2);
        double ty1 = (this.min.y - r.p.y) * r.inv.y;
        double ty2 = (this.max.y - r.p.y) * r.inv.y;
        tmin = Math.max(tmin, Math.min(ty1, ty2));
        tmax = Math.min(tmax, Math.max(ty1, ty2));
        double tz1 = (this.min.z - r.p.z) * r.inv.z;
        double tz2 = (this.max.z - r.p.z) * r.inv.z;
        return (tmin = Math.max(tmin, Math.min(tz1, tz2))) < (tmax = Math.min(tmax, Math.max(tz1, tz2))) ? tmin : Double.POSITIVE_INFINITY;
    }
}

