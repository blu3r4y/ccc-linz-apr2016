/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Vector3D;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Ray {
    public final Vector3D p;
    final Vector3D d;
    final Vector3D inv;

    public Ray(Vector3D p, Vector3D d) {
        this.p = p;
        this.d = d;
        this.inv = d.inv();
    }

    public static Ray down(Vector3D p) {
        return new Ray(p, Vector3D.DOWN);
    }

    public static Ray up(Vector3D p) {
        return new Ray(p, Vector3D.UP);
    }

    @SideEffectFree
    public String toString() {
        return this.p + " " + this.d;
    }
}

