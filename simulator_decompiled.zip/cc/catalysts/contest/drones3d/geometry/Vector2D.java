/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Vector3D;
import org.checkerframework.dataflow.qual.Pure;
import org.checkerframework.dataflow.qual.SideEffectFree;

public class Vector2D {
    public final double x;
    public final double y;

    public static Vector2D dia(double v) {
        return new Vector2D(v, v);
    }

    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Vector2D() {
        this(0.0, 0.0);
    }

    public double distanceTo(Vector2D v) {
        return Math.sqrt(Math.pow(this.x - v.x, 2.0) + Math.pow(this.y - v.y, 2.0));
    }

    public double dotProduct(Vector2D v) {
        return this.x * v.x + this.y * v.y;
    }

    public double mag() {
        return Math.sqrt(Math.pow(this.x, 2.0) + Math.pow(this.y, 2.0));
    }

    public double get(int axis) {
        switch (axis) {
            case 0: {
                return this.x;
            }
            case 1: {
                return this.y;
            }
        }
        throw new IllegalArgumentException();
    }

    public Vector3D toVector3D() {
        return new Vector3D(this.x, this.y, 0.0);
    }

    @SideEffectFree
    public String toString() {
        return "" + this.x + " " + this.y;
    }

    @Pure
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Vector3D v = (Vector3D)o;
        return Double.compare(v.x, this.x) == 0 && Double.compare(v.y, this.y) == 0;
    }

    @Pure
    public int hashCode() {
        long temp = Double.doubleToLongBits(this.x);
        int result = (int)(temp ^ temp >>> 32);
        temp = Double.doubleToLongBits(this.y);
        result = 31 * result + (int)(temp ^ temp >>> 32);
        return result;
    }
}

