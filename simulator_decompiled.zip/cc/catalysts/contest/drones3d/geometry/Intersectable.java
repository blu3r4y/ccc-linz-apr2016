/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d.geometry;

import cc.catalysts.contest.drones3d.geometry.Ray;

public interface Intersectable {
    public double intersects(Ray var1);
}

