/*
 * Decompiled with CFR 0_114.
 */
package cc.catalysts.contest.drones3d;

import cc.catalysts.contest.drones3d.geometry.Vector3D;

public interface Locatable {
    public Vector3D getLocation();

    public double distanceTo(Locatable var1);

    public double distanceTo(Vector3D var1);
}

