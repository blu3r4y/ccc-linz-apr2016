/*
 * Decompiled with CFR 0_114.
 */
package com.google.common.annotations;

import com.google.common.annotations.GwtCompatible;
import java.lang.annotation.Annotation;

@GwtCompatible
public @interface VisibleForTesting {
}

