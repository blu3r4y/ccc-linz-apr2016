/*
 * Decompiled with CFR 0_114.
 */
package com.google.common.base;

public interface FinalizableReference {
    public void finalizeReferent();
}

