/*
 * Decompiled with CFR 0_114.
 * 
 * Could not load the following classes:
 *  javax.annotation.ParametersAreNonnullByDefault
 */
package com.google.common.base;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
interface package-info {
}

