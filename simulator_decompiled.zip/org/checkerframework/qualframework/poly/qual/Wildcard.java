/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.qualframework.poly.qual;

public enum Wildcard {
    NONE,
    EXTENDS,
    SUPER;
    

    private Wildcard() {
    }
}

