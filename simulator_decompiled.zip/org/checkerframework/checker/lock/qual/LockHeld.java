/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.lock.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.checkerframework.checker.lock.qual.LockPossiblyHeld;
import org.checkerframework.framework.qual.DefaultFor;
import org.checkerframework.framework.qual.SubtypeOf;
import org.checkerframework.framework.qual.TypeUseLocation;

@SubtypeOf(value={LockPossiblyHeld.class})
@Documented
@Retention(value=RetentionPolicy.RUNTIME)
@DefaultFor(value={TypeUseLocation.LOWER_BOUND})
@Target(value={ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
public @interface LockHeld {
}

