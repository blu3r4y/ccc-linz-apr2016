/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.signature.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import org.checkerframework.checker.signature.qual.BinaryNameForNonArray;
import org.checkerframework.checker.signature.qual.SourceNameForNonInner;
import org.checkerframework.framework.qual.SubtypeOf;

@SubtypeOf(value={SourceNameForNonInner.class, BinaryNameForNonArray.class})
@Target(value={ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
public @interface SourceNameForNonArrayNonInner {
}

