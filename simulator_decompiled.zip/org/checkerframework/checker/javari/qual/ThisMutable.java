/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.javari.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.Target;
import org.checkerframework.checker.javari.qual.ReadOnly;
import org.checkerframework.framework.qual.DefaultFor;
import org.checkerframework.framework.qual.SubtypeOf;
import org.checkerframework.framework.qual.TypeUseLocation;

@Target(value={})
@SubtypeOf(value={ReadOnly.class})
@DefaultFor(value={TypeUseLocation.FIELD})
public @interface ThisMutable {
}

