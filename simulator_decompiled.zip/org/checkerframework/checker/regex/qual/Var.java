/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.regex.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.checkerframework.checker.regex.qual.MultiVar;
import org.checkerframework.qualframework.poly.qual.Wildcard;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@Repeatable(value=MultiVar.class)
public @interface Var {
    public String arg() default "_primary";

    public String param() default "_primary";

    public Wildcard wildcard() default Wildcard.NONE;
}

