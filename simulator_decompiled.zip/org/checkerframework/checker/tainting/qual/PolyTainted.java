/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.tainting.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.checkerframework.checker.tainting.qual.MultiPolyTainted;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@Repeatable(value=MultiPolyTainted.class)
public @interface PolyTainted {
    public String param() default "_primary";
}

