/*
 * Decompiled with CFR 0_114.
 * 
 * Could not load the following classes:
 *  org.checkerframework.checker.units.UnitsRelations
 */
package org.checkerframework.checker.units.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(value=RetentionPolicy.RUNTIME)
public @interface UnitsRelations {
    public Class<? extends org.checkerframework.checker.units.UnitsRelations> value();
}

