/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.checker.nullness;

import org.checkerframework.checker.nullness.qual.EnsuresNonNull;

public final class NullnessUtils {
    private NullnessUtils() {
        throw new AssertionError((Object)"shouldn't be instantiated");
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T castNonNull(T ref) {
        assert (ref != null);
        return ref;
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T[] castNonNullDeep(T[] arr) {
        return NullnessUtils.castNonNullArray(arr);
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T[][] castNonNullDeep(T[][] arr) {
        return (Object[][])NullnessUtils.castNonNullArray(arr);
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T[][][] castNonNullDeep(T[][][] arr) {
        return (Object[][][])NullnessUtils.castNonNullArray(arr);
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T[][][][] castNonNullDeep(T[][][][] arr) {
        return (Object[][][][])NullnessUtils.castNonNullArray(arr);
    }

    @EnsuresNonNull(value={"#1"})
    public static <T> T[][][][][] castNonNullDeep(T[][][][][] arr) {
        return (Object[][][][][])NullnessUtils.castNonNullArray(arr);
    }

    private static <T> T[] castNonNullArray(T[] arr) {
        assert (arr != null);
        for (int i = 0; i < arr.length; ++i) {
            assert (arr[i] != null);
            NullnessUtils.checkIfArray(arr[i]);
        }
        return arr;
    }

    private static void checkIfArray(Object ref) {
        assert (ref != null);
        Class comp = ref.getClass().getComponentType();
        if (comp != null && !comp.isPrimitive()) {
            NullnessUtils.castNonNullArray((Object[])ref);
        }
    }
}

