/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.framework.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.lang.model.type.TypeKind;
import org.checkerframework.framework.qual.LiteralKind;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.ANNOTATION_TYPE})
public @interface ImplicitFor {
    public LiteralKind[] literals() default {};

    public TypeKind[] types() default {};

    public Class<?>[] typeNames() default {};

    public String[] stringPatterns() default {};
}

