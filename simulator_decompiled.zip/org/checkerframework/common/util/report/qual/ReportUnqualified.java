/*
 * Decompiled with CFR 0_114.
 */
package org.checkerframework.common.util.report.qual;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import org.checkerframework.framework.qual.DefaultQualifierInHierarchy;
import org.checkerframework.framework.qual.InvisibleQualifier;
import org.checkerframework.framework.qual.SubtypeOf;

@InvisibleQualifier
@SubtypeOf(value={})
@DefaultQualifierInHierarchy
@Target(value={ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
public @interface ReportUnqualified {
}

