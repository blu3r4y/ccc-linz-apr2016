package at.ccc;

/**
 * Created by Peter on 08.04.2016.
 */
public class Drone {
    int id;

    int mass = 2;
    int len = 1;
    int width = 1;
    double height = 0.5;
    int rotorCount = 8;
    double rotorDia = 0.25;
    int maxVel = 14;

    double airDensity = 1.225;

    double C = 0.015;
    double RpmMax = 10000;

    double xPos;
    double yPos;
    double zPos;

    double xVector;
    double yVector;
    double zVector;

    double xSpeed;
    double ySpeed;
    double zSpeed;

    double xTarget;
    double yTarget;
    double zTarget;

    double hoverArea;

    boolean isLanded = false;

    double grav= 9.8;

    Drone(int id) {
        this.id = id;
        hoverArea = (id+1) * 3;
    }

    double getThrottle(double speed) {
        double start = 0.195154;
        double X =Math.pow(speed,3.0);
        System.out.println("X" + X);
        double form = (5.0/32.0);
        System.out.println("form" + form);
        double Y =Math.pow(X,form);
        System.out.println("Y" + Y);
        start = start * Y;
        System.out.println("start" + start);
        return start;


    }

    double getAccel(double throttle) {
        double t = 0;

        double power = getPower(throttle);
        //System.out.println("power" + power);
        double inRoot = ((Math.PI / 2) * rotorDia * rotorDia * airDensity * power * power);
        //System.out.println("inRoot " + inRoot);
        t = Math.pow(inRoot, (1.0/3.0));
        //System.out.println("t " + t);
        double force = t*rotorCount;
        return (force);//-grav;
    }

    double getPower(double throttle) {
        return  C* Math.pow(((throttle * RpmMax)/1000), 3.2);
    }

}
