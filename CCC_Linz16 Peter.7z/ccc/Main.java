package at.ccc;

import at.coffee.util.network.Communicator;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Main {

    public static Communicator c;
    public static String command;

    static int xMin;
    static int xMax;
    static int yMin;
    static int yMax;

    static double xTarget;
    static double yTarget;
    static double zTarget;

    static double equilibrum = 0.569;


    public static double getThrottleForSpeed(Drone d,double speed) {
        for(double i = 0; i < 1; i+=0.00000001) {
            if(d.getAccel(i) + d.zSpeed == speed) {
                return i;
            }
        }
        return 0;
    }

    public static void main(String[] args) throws IOException {
        Drone d = new Drone(0);
        List<Drone> drones = new LinkedList<Drone>();

        System.out.println(d.getPower(0.3));
        double t = d.getThrottle(1);
        System.out.println(t);
        System.out.println(d.getAccel(t));
        //System.out.println(d.getThrottle(2));
        //System.out.println(d.getThrottle(4));
        System.out.println(getThrottleForSpeed(d,1));
        c = new Communicator("127.0.0.1", 9000);
        System.out.println(c.getLineFromConnection());
        int cnt = Integer.parseInt(c.getLineFromConnection());
        for(int i = 0; i < cnt; i++) {
            Drone dx = new Drone(i);
            drones.add(dx);
        }

        System.out.println(cnt);
        for (int i = 0; i < cnt; i++) {
            System.out.println("Target "+ i + " " );
            String line[] = c.getLineFromConnection().split(" ");
            drones.get(i).xTarget = Double.parseDouble(line[0]);
            drones.get(i).yTarget = Double.parseDouble(line[1]);
            drones.get(i).zTarget = Double.parseDouble(line[2]);

            System.out.println("Target "+ i + " " + drones.get(i).xTarget + " " + drones.get(i).yTarget + " " + drones.get(i).zTarget);

        }

        goToTargets(drones);
    }

    private static void goToTargets(List<Drone> d) throws IOException {
        int landed = 0;
        while(landed != d.size()) {
            for (int i = 0; i < d.size(); i++) {
                if (d.get(i).isLanded) {
                    landed++;
                    continue;
                }
                goToTarget(d.get(i));
            }
            tick(1);
            c.getLineFromConnection();
            landed = 0;
            for(int i = 0; i < d.size(); i++) {
                getStatus(d.get(i));
            }
        }
    }

    private static void goToTarget(Drone d) throws IOException {
        if(d.hoverArea < d.zPos) {
            getTurn(d);
        }
        boolean fall = false;
        //Right X
        if(d.xTarget +1 > d.xPos && d.xTarget-1 < d.xPos) {
            if(d.yTarget +1 > d.yPos && d.yTarget-1 < d.yPos) {
                slowFallTo(d, 0.3);
                fall = true;
                if(d.zPos < 0.3) {
                    throttleDrone(d.id, 0);
                    land(d.id);
                    d.isLanded = true;
                }
            }
        }
        if(!fall) {
            hoverUp(d, d.hoverArea);
        }
    }

    private static void getTurn(Drone d) throws IOException {
        double x = 0;
        double y = 0;
        if(d.xTarget > d.xPos && d.xSpeed <= 0) {
            x = 0.01;
        } else if (d.xPos > d.xTarget && d.xSpeed >= 0){
            x = -0.01;
        }
        if(d.yTarget > d.yPos && d.ySpeed <= 0) {
            y = 0.01;
        } else if(d.yPos > d.yTarget && d.ySpeed >= 0) {
            y = -0.01;
        }
        if(d.xVector != 0) {
            x = -d.xVector;
        }
        if(d.yVector != 0) {
            y = -d.yVector;
        }
        turnDrone(d.id, x,y,0);
    }

    private static void hoverDrones(List<Drone> d) throws IOException {
        int cnt = 0;
        while (cnt < 12*d.size()) {
            for(int i = 0; i < d.size(); i++) {
                getStatus(d.get(i));
                riseTo(d.get(i), 20);
                if (d.get(i).zPos > 20 && d.get(i).zPos < 40) {
                    cnt++;
                }
            }
            tick(1);
            c.getLineFromConnection();
        }
        int landed = 0;
        List<Boolean> preLanded = new LinkedList<Boolean>();
        List<Boolean> isLanded = new LinkedList<Boolean>();
        for (int x = 0; x < d.size(); x++) {
            isLanded.add(Boolean.FALSE);
            preLanded.add(Boolean.FALSE);
        }
        while(landed < d.size()) {
            for (int i = 0; i < d.size(); i++) {
                if (!isLanded.get(i) && d.get(i).zPos > 0.3) {
                    slowFallTo(d.get(i), 0.3);
                    getStatus(d.get(i));
                } else {
                    throttleDrone(d.get(i).id, 0.0);
                    land(d.get(i).id);
                    landed++;
                    isLanded.set(i, Boolean.TRUE);;
                }
            }
            tick(1);
            c.getLineFromConnection();
        }

    }

    private static void landDrone(Drone d) throws IOException {
        while(d.zPos > 0.3) {
            slowFallTo(d, 0.3);
            tick(1);
            c.getLineFromConnection();
            getStatus(d);
        }
        throttleDrone(d.id, 0);
        land(d.id);
        tick(1);
        //System.out.println(c.getLineFromConnection());
    }

    private static void hoverDrone(Drone d, int meter) throws IOException {
        int i = 0;
        while (i < 12) {
            riseTo(d, meter);
            tick(1);
            c.getLineFromConnection();
            getStatus(d);
            if (d.zPos > 20 && d.zPos < 40) {
                i++;
            }
        }
    }

    private static void slowFallTo(Drone d, double h) throws IOException {
        if(d.zPos > h) {
            double slowThrottle = getSlowFallSpeed(d);
            throttleDrone(d.id, slowThrottle);
            //System.out.println("Slow " + slowThrottle);

        } else {
            throttleDrone(d.id, equilibrum+0.001);
        }
    }

    public static void tick(int sec) throws IOException {
        c.writeLineToConnection("TICK " + sec);
    }

    public static void land(int id) throws IOException {
        c.writeLineToConnection("LAND " + id);
        c.getLineFromConnection();
    }

    public static void turnDrone(int id, double x, double y, double z) throws IOException {
        c.writeLineToConnection("TURN " + id + " " + x + " " + y+ " " +z);
        c.getLineFromConnection();
    }


    public static void throttleDrone(int id, double throttle) throws IOException {
        command = "THROTTLE "+  id + " " + throttle;
        //System.out.println(command);
        c.writeLineToConnection(command);
        c.getLineFromConnection();
        c.toString();
    }

    public static void getStatus(Drone d) throws IOException {
        c.writeLineToConnection("STATUS " + d.id);
        String line = c.getLineFromConnection();
        System.out.println(d.id + " " + line);
        String[] split = line.split(" ");
        d.xPos = Double.parseDouble(split[0]);
        d.yPos = Double.parseDouble(split[1]);
        d.zPos = Double.parseDouble(split[2]);
        d.xSpeed= Double.parseDouble(split[3]);
        d.ySpeed= Double.parseDouble(split[4]);
        d.zSpeed = Double.parseDouble(split[5]);
        d.xVector = Double.parseDouble(split[6]);
        d.yVector = Double.parseDouble(split[7]);
        d.zVector = Double.parseDouble(split[8]);
    }

    public static void hoverUp(Drone d, double h) throws IOException {
        if(d.zPos > h) {
            double slowThrottle = getBreakingSpeed(d);
            throttleDrone(d.id, slowThrottle);
        } else {
            throttleDrone(d.id, 0.58);
        }
    }

    public static void riseTo(Drone d, double h) throws IOException {
        if(d.zPos > h) {
            double slowThrottle = getBreakingSpeed(d);
            throttleDrone(d.id, slowThrottle);
        } else {
            throttleDrone(d.id, 0.58);
        }
    }

    private static double getSlowFallSpeed(Drone d) {
        for(double i = 0; i < equilibrum+1; i+=0.001) {
            if(d.getAccel(i) + d.zSpeed < -0.1 && d.getAccel(i) + d.zSpeed > -0.15) {
                //System.out.println(i);
                return i;
            }
        }
        return equilibrum;
    }

    private static double getBreakingSpeed(Drone d) {
        for(double i = 0; i < equilibrum+1; i+=0.0001) {
            if((d.getAccel(i) + d.zSpeed) < 0.05 && d.getAccel(i) + d.zSpeed > -0.05) {
                //System.out.println(i);
                return i;
            }
        }
        return equilibrum;
    }

    public static void level1(Drone d) throws IOException {
        //System.out.println("Accel" + d.getAccel(0.7));
        //System.out.println("Power" + d.getPower(0.7));
        throttleDrone(0,0.7);
        tick(2);
        getStatus(d);
        throttleDrone(0,equilibrum);
        tick(6);
        getStatus(d);
        System.out.println(c.getLineFromConnection());
        System.out.println(c.getLineFromConnection());
    }
}
